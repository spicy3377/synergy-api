Synergy-admin-api

