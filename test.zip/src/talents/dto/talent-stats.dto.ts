export class TalentStatsDto {
  name: string;
  data: number[];
}
